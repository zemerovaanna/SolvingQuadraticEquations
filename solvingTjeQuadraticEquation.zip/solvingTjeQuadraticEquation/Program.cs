﻿// See https://aka.ms/new-console-template for more information

double a, b, c;
string decision;

Console.Write("a = ");
a = Convert.ToDouble(Console.ReadLine());
Console.Write("b = ");
b = Convert.ToDouble(Console.ReadLine());
Console.Write("c = ");
c = Convert.ToDouble(Console.ReadLine());

decision = calculation(a, b, c);
Console.WriteLine("Conclusion: " + decision);

Console.ReadKey();

static string calculation(double a, double b, double c)
{
    double D;
    double x, x1, x2;

    Math.Round(a, 3);
    Math.Round(b, 3);
    Math.Round(c, 3);

    D = (b * 2) - 4 * a * c;

    if (D < 0)
    {
        return "There are no valid roots."; //Действительных корней нет.
    }
    else if (D == 0)
    {
        x = (b * (-1)) / 2 * a;

        return $"The solution is any real number.\nX = {x}"; //Решение – любое действительное число.
    }
    else //if (D > 0)
    {
        x1 = (b * (-1)) + Math.Sqrt(D) / 2 * a;
        x2 = (b * (-1)) - Math.Sqrt(D) / 2 * a;

        return $"X1, X2 – valid roots.\nX1 = {x1}, X2 = {x2}."; //– действительные корни.
    }
}